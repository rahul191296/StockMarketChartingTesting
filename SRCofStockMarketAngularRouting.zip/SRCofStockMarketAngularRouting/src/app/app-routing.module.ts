import{NgModule}from'@angular/core';
import{RouterModule,Routes} from '@angular/router'
import { LoginComponent } from './login/login.component';
import { UserComponent } from './user/user.component';
import { AdminComponent } from './admin/admin.component';
import { NavgbarComponent } from './navgbar/navgbar.component';
import { CompareCompanyComponent } from './compare-company/compare-company.component';
import { AddCompanyComponent } from './add-company/add-company.component';
import { StockComponent } from './stock/stock.component';
import { CompanyManagementComponent } from './company-management/company-management.component';
import { RegistrationComponent } from './registration/registration.component';
import { IpoComponent } from './ipo/ipo.component';

const routes: Routes=[
    {path:'login',component:LoginComponent},
    {path:'user',component:UserComponent},
    {path:'admin',component:AdminComponent},
    {path:'navgbar',component:NavgbarComponent},
    {path:'compare-company',component:CompareCompanyComponent},
    {path:'add-company',component:AddCompanyComponent},
    {path:'stock',component:StockComponent},
    {path:'company-management',component:CompanyManagementComponent},
    {path:'registration',component:RegistrationComponent},
    {path:'ipo',component:IpoComponent}
    
   ]
@NgModule({
    imports: [RouterModule.forRoot(routes)],
    exports: [RouterModule]})
    
export class AppRoutingModule{


       
}export const
RoutingComponent = [LoginComponent,UserComponent,AdminComponent,NavgbarComponent,CompareCompanyComponent,AddCompanyComponent,StockComponent,CompanyManagementComponent,RegistrationComponent,IpoComponent]