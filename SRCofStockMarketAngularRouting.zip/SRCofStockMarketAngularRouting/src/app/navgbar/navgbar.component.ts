import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-navgbar',
  templateUrl: './navgbar.component.html',
  styleUrls: ['./navgbar.component.css']
})
export class NavgbarComponent implements OnInit {
  isCollapsed: boolean=true;
 
  constructor() { }

  ngOnInit() {
  }
  toggleCollapse(){

    this.isCollapsed= !this.isCollapsed;
  }

}
