import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-ipo',
  templateUrl: './ipo.component.html',
  styleUrls: ['./ipo.component.css']
})
export class IpoComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
