import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppComponent } from './app.component';
import { LoginComponent } from './login/login.component';
import { UserComponent } from './user/user.component';
import { AdminComponent } from './admin/admin.component';
import { AppRoutingModule } from './app-routing.module';
import { NavgbarComponent } from './navgbar/navgbar.component';
import { CompareCompanyComponent } from './compare-company/compare-company.component';
import { AddCompanyComponent } from './add-company/add-company.component';
import { StockComponent } from './stock/stock.component';
import { CompanyManagementComponent } from './company-management/company-management.component';
import { RegistrationComponent } from './registration/registration.component';
import { IpoComponent } from './ipo/ipo.component';

@NgModule({
  declarations: [
    AppComponent,
    LoginComponent,
    UserComponent,
    AdminComponent,
    NavgbarComponent,
    CompareCompanyComponent,
    AddCompanyComponent,
    StockComponent,
    CompanyManagementComponent,
    RegistrationComponent,
    IpoComponent
  ],
  imports: [
    BrowserModule,AppRoutingModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
